************************************************
Encore Insights: Country Dashboard Data Download
************************************************

## About ##

This zip folder contains data (version 3.0) from the ENCORE Insights: Country Dashboard which has been developed as part of the Horizon Europe Nature 3B Project by Global Canopy (https://globalcanopy.org).

This data download includes the following files:
1. country_headline_figures.csv: Country level headline figures of value highly exposed in GVA and IVA (million Euros)
2. sector_dependency_levels.csv: Monetary values of dependency (million Euros): high, medium and low dependency for GVA and IVA at country, sector level
3. subsector_economic_data.csv: Country - Subsector level data: Economic size (GVA and IVA in million Euros)for each component.
4. ecosystem_services_domestic.csv and ecosystem_services_foreign.csv: mean weighted ecosystem service dependencies for domestic and foreign upstream suppliers respectively
5. employment_dependencies_pba.csv: Jobs and wages high, medium and low dependency within domestic production (thousands people; million Euros wages)
6. nature_dependency_ratings.csv: subsector level upstream nature dependency ratings (weighted mean dependency of domestic and foreign suppliers respectively)
7. country_codes.csv: A key of EU27 country code to country name plus UK and Switzerland. Note: high level metrics are only provide for EU27 countries plus UK and Switzerland
8. sector_subsector_mapping.csv: Mapping of subsectors to sector groups with row 1 as sector group and row 2 - row showing subsectors
9. EXIOBASE NACE ISIC crosswalk.csv: The crosswalk table between EXIOBASE NACE and ISIC economic activities as provided and available for download from ENCORE at encorenature.org.

The full methodology can be downloaded from https://countries.encorenature.org. Definitions can be found on the Dashboard.

A key to the economic components codes used in the csvs is below and full methodological calculations in the methodology document:

Component	| Domestic	| Imported
-------------------------------------------
Production	| GVA		| IVA
Consumption	| CBA_dom	| CBA_imp
Exports		| DC		| FX

## Use and Licensing ##

Global Canopy grants permission to use the information contained in this zip folder under the terms of a CC BY-SA 4.0 license, strictly subject to attribution being provided to Global Canopy alongside original sources.

The contents of the data files contained in this zip folder do not necessarily reflect the views or policies of Global Canopy, contributory organisations or editors. 

By using the information contained in this zip folder you agree to the Terms and Conditions of Encore Insights: Country Dashboard (available to view at https://countries.encorenature.org/legal).

## Attribution ##

To reference this data in publications, analysis, and reports, the User must ensure that the following citation is always clearly reproduced in any publication or analysis involving the data in any derived form or format:
Global Canopy (2026). ENCORE Insights: Country Dashboard. Part of Horizon Europe Nature3B project. [On-line], [insert month/year of the version downloaded], Oxford, UK. Available at countries.encorenature.org. DOI: https://zenodo.org/records/17803534